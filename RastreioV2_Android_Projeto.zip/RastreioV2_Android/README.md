# Rastreio V2 — aplicação Android (projecto-fonte)

## Servidor configurado
https://ftec.epizy.com/rastreio-v2

## O que este protótipo faz
- Regista o telefone através de `api/dispositivos/registrar.php`.
- Guarda localmente o token recebido.
- Com consentimento e permissões Android, inicia um serviço de localização visível.
- Envia latitude, longitude, precisão, altitude, velocidade em km/h, bateria e data para `api/localizacao/enviar.php`.
- Permite parar a partilha no próprio telefone.

## Requisitos
- Android Studio recente
- JDK 17
- Internet durante a primeira compilação para descarregar dependências Gradle

## Como abrir e gerar o APK
1. Extraia o ZIP.
2. Abra a pasta `RastreioV2_Android` no Android Studio.
3. Aguarde a sincronização Gradle.
4. Use **Build > Build APK(s)**.
5. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.
6. Instale no telefone de teste e conceda localização e notificações quando solicitadas.

## Como usar
1. Confirme que os endpoints estão neste caminho:
   - `/api/dispositivos/registrar.php`
   - `/api/localizacao/enviar.php`
2. Abra a app, confirme o endereço HTTPS, introduza o ID da sua conta em `usuarios.id` e um nome para o telefone.
3. Marque a autorização e toque em **Registar telefone**.
4. Depois do registo, toque em **Iniciar partilha de localização**.
5. Para terminar, toque em **Parar partilha**.

## Limitações e segurança importantes
- Isto é um projecto-fonte, não um APK pré-compilado nem uma versão testada em dispositivo real.
- O endpoint `registrar.php` descrito pelo proprietário aceita `usuario_id` sem validar palavra-passe/sessão; não o exponha publicamente assim. Antes de uso real, implemente autenticação segura e autorização do utilizador.
- O alojamento gratuito InfinityFree pode bloquear chamadas API vindas directamente de aplicações, mesmo que abra PHP no navegador. Se houver resposta 403, página HTML de verificação ou erro semelhante, será necessário um alojamento compatível com API.
- A localização funciona enquanto o Android permitir o serviço em primeiro plano e a notificação estiver visível. Fabricantes podem suspender o serviço por poupança de bateria.
- Não recolhe SMS, chamadas, IMEI, áudio ou conversas.
- A data enviada usa UTC; confirme se o seu PHP ou painel converte correctamente para hora local.
- Não há fila offline persistente nesta versão: se falhar a rede, essa posição pode não ser enviada.
