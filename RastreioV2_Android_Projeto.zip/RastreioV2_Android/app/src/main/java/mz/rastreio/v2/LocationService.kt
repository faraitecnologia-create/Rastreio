package mz.rastreio.v2

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import okhttp3.*
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class LocationService : Service() {
    private val client = OkHttpClient()
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var callback: LocationCallback

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, notification("A partilhar localização com autorização"))
        fused = LocationServices.getFusedLocationProviderClient(this)
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { sendLocation(it) }
            }
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 60_000L)
            .setMinUpdateIntervalMillis(30_000L)
            .setMinUpdateDistanceMeters(20f)
            .build()
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fused.requestLocationUpdates(request, callback, Looper.getMainLooper())
        } else {
            stopSelf()
        }
    }

    private fun sendLocation(location: Location) {
        val prefs = getSharedPreferences("rastreio", MODE_PRIVATE)
        val base = prefs.getString("server", "")?.trimEnd('/').orEmpty()
        val token = prefs.getString("token", "").orEmpty()
        if (base.isBlank() || token.isBlank()) return
        val battery = try {
            val intent = registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra("level", -1) ?: -1
            val scale = intent?.getIntExtra("scale", -1) ?: -1
            if (level >= 0 && scale > 0) (level * 100 / scale).toString() else "0"
        } catch (_: Exception) { "0" }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val body = FormBody.Builder()
            .add("token", token)
            .add("latitude", location.latitude.toString())
            .add("longitude", location.longitude.toString())
            .add("precisao_m", location.accuracy.toString())
            .add("altitude", location.altitude.toString())
            .add("velocidade", (location.speed * 3.6f).toString())
            .add("bateria", battery)
            .add("data_registo", dateFormat.format(Date()))
            .build()

        val request = Request.Builder().url("$base/api/localizacao/enviar.php").post(body).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { /* Próxima localização tenta novamente. */ }
            override fun onResponse(call: Call, response: Response) { response.close() }
        })
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("rastreio_location", "Rastreio V2", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, "rastreio_location")
            .setContentTitle("Rastreio V2")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        if (::fused.isInitialized && ::callback.isInitialized) fused.removeLocationUpdates(callback)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
