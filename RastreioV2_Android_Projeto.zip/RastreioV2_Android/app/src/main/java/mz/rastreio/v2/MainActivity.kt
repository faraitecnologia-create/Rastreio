package mz.rastreio.v2

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import java.io.IOException

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private lateinit var serverField: EditText
    private lateinit var userIdField: EditText
    private lateinit var nameField: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("rastreio", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "📍 Rastreio V2"
            textSize = 26f
            gravity = Gravity.CENTER
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply {
            text = "Localização partilhada com autorização"
            textSize = 14f
            gravity = Gravity.CENTER
        }, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        serverField = addField(root, "Endereço base do servidor",
            prefs.getString("server", "https://ftec.epizy.com/rastreio-v2") ?: "")
        userIdField = addField(root, "ID da sua conta (usuario_id)",
            prefs.getString("user_id", "") ?: "")
        nameField = addField(root, "Nome deste telefone",
            prefs.getString("device_name", "Meu Telefone") ?: "Meu Telefone")

        val consent = CheckBox(this).apply {
            text = "Autorizo este telefone a partilhar a localização com a minha conta."
            textSize = 14f
        }
        root.addView(consent, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        status = TextView(this).apply {
            text = "Estado: ainda não registado"
            textSize = 14f
            setPadding(0, 18, 0, 18)
        }
        root.addView(status)

        val register = Button(this).apply { text = "Registar telefone" }
        root.addView(register, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        register.setOnClickListener {
            if (!consent.isChecked) {
                status.text = "Confirme a autorização antes de continuar."
                return@setOnClickListener
            }
            val base = serverField.text.toString().trim().trimEnd('/')
            val uid = userIdField.text.toString().trim().toIntOrNull()
            val deviceName = nameField.text.toString().trim()
            if (!base.startsWith("https://") || uid == null || uid <= 0 || deviceName.isBlank()) {
                status.text = "Verifique o endereço HTTPS, o ID da conta e o nome."
                return@setOnClickListener
            }
            prefs.edit().putString("server", base).putString("user_id", uid.toString())
                .putString("device_name", deviceName).apply()
            registerDevice(base, uid, deviceName)
        }

        val start = Button(this).apply { text = "Iniciar partilha de localização" }
        root.addView(start, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        start.setOnClickListener {
            if (!consent.isChecked) {
                status.text = "É necessário consentimento explícito."
                return@setOnClickListener
            }
            if (prefs.getString("token", null).isNullOrBlank()) {
                status.text = "Registe primeiro o telefone."
                return@setOnClickListener
            }
            requestLocationPermissions()
        }

        val stop = Button(this).apply { text = "Parar partilha" }
        root.addView(stop, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        stop.setOnClickListener {
            stopService(Intent(this, LocationService::class.java))
            status.text = "Partilha parada neste telefone."
        }

        setContentView(root)
    }

    private fun addField(root: LinearLayout, label: String, initial: String): EditText {
        val wrapper = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrapper.addView(TextView(this).apply { text = label; textSize = 13f })
        val edit = EditText(this).apply {
            setText(initial)
            textSize = 16f
            singleLine = true
        }
        wrapper.addView(edit)
        root.addView(wrapper, match(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return edit
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun registerDevice(base: String, uid: Int, deviceName: String) {
        status.text = "A registar telefone..."
        val body = FormBody.Builder()
            .add("usuario_id", uid.toString())
            .add("nome", deviceName)
            .add("modelo", "${Build.MANUFACTURER} ${Build.MODEL}")
            .add("imei", "")
            .add("plataforma", "android")
            .build()
        val request = Request.Builder()
            .url("$base/api/dispositivos/registrar.php")
            .post(body).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { status.text = "Falha de ligação: ${e.localizedMessage ?: "erro de rede"}" }
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val text = it.body?.string().orEmpty()
                    val json = try { org.json.JSONObject(text) } catch (_: Exception) { null }
                    runOnUiThread {
                        if (!it.isSuccessful || json == null || !json.optBoolean("ok")) {
                            status.text = "O servidor não aceitou o registo (HTTP ${it.code}). Verifique o alojamento/API."
                            return@runOnUiThread
                        }
                        val device = json.optJSONObject("dispositivo")
                        val token = device?.optString("token", "").orEmpty()
                        val id = device?.optInt("id", 0) ?: 0
                        if (token.isBlank() || id <= 0) {
                            status.text = "Resposta incompleta da API. Confirme registrar.php."
                            return@runOnUiThread
                        }
                        getSharedPreferences("rastreio", MODE_PRIVATE).edit()
                            .putString("token", token).putInt("device_id", id).apply()
                        status.text = "Telefone registado. ID do dispositivo: $id"
                    }
                }
            }
        })
    }

    private fun requestLocationPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 202)
        } else {
            startLocationService()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 202) {
            if (grantResults.isNotEmpty() && grantResults.any { it == PackageManager.PERMISSION_GRANTED } &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startLocationService()
            } else {
                status.text = "Permissão de localização recusada."
            }
        }
    }

    private fun startLocationService() {
        val intent = Intent(this, LocationService::class.java)
        ContextCompat.startForegroundService(this, intent)
        status.text = "Partilha iniciada. A notificação do Android ficará visível."
    }
}
